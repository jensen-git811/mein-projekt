#!/system/bin/sh

LOG_FILE="/data/adb/cellsentinel-diag.log"
DISABLE_FLAG="/data/adb/cellsentinel-diag.disable"
TARGET_USB_FUNCS="diag,adb"
TARGET_PERSIST_PROPS="
persist.sys.usb.config
persist.vendor.usb.config
persist.service.adb.enable
persist.usb.config
"

log_msg() {
  echo "$(date '+%F %T') [CellSentinel] $*" >> "$LOG_FILE"
}

set_prop() {
  local key="$1"
  local value="$2"

  resetprop -n "$key" "$value" 2>/dev/null || setprop "$key" "$value"
}

if [ -f "$DISABLE_FLAG" ]; then
  log_msg "Disable flag present, skipping post-fs-data setup."
  exit 0
fi

CURRENT="$(getprop persist.sys.usb.config)"
if echo "$CURRENT" | grep -q "diag"; then
  log_msg "persist.sys.usb.config already contains diag: $CURRENT"
else
  log_msg "Setting persist.sys.usb.config to $TARGET_USB_FUNCS"
  set_prop persist.sys.usb.config "$TARGET_USB_FUNCS"
fi

VENDOR_CURRENT="$(getprop persist.vendor.usb.config)"
if [ -n "$VENDOR_CURRENT" ] && ! echo "$VENDOR_CURRENT" | grep -q "diag"; then
  log_msg "Setting persist.vendor.usb.config to $TARGET_USB_FUNCS"
  set_prop persist.vendor.usb.config "$TARGET_USB_FUNCS"
fi

SERVICE_ADB="$(getprop persist.service.adb.enable)"
if [ "$SERVICE_ADB" != "1" ]; then
  log_msg "Forcing persist.service.adb.enable=1"
  set_prop persist.service.adb.enable 1
fi

USB_CONFIG="$(getprop persist.usb.config)"
if [ -z "$USB_CONFIG" ] || ! echo "$USB_CONFIG" | grep -q "diag"; then
  log_msg "Setting persist.usb.config to $TARGET_USB_FUNCS"
  set_prop persist.usb.config "$TARGET_USB_FUNCS"
fi
