#!/system/bin/sh

LOG_FILE="/data/adb/cellsentinel-diag.log"
DISABLE_FLAG="/data/adb/cellsentinel-diag.disable"
TARGET_USB_FUNCS="diag,adb"
SVC_BIN="$(command -v svc 2>/dev/null)"
RESETPROP_BIN="$(command -v resetprop 2>/dev/null)"

log_msg() {
  echo "$(date '+%F %T') [CellSentinel] $*" >> "$LOG_FILE"
}

set_prop() {
  local key="$1"
  local value="$2"

  if [ -n "$RESETPROP_BIN" ]; then
    "$RESETPROP_BIN" -n "$key" "$value" >/dev/null 2>&1 || setprop "$key" "$value"
  else
    setprop "$key" "$value"
  fi
}

wait_for_boot() {
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
  done
}

if [ -f "$DISABLE_FLAG" ]; then
  log_msg "Disable flag present, service exiting."
  exit 0
fi

wait_for_boot
sleep 8

if [ -n "$SVC_BIN" ]; then
  log_msg "Trying svc usb setFunctions $TARGET_USB_FUNCS"
  "$SVC_BIN" usb setFunctions "$TARGET_USB_FUNCS" >/dev/null 2>&1
fi

log_msg "Setting sys.usb.config to $TARGET_USB_FUNCS"
set_prop sys.usb.config "$TARGET_USB_FUNCS"
set_prop persist.sys.usb.config "$TARGET_USB_FUNCS"
set_prop persist.vendor.usb.config "$TARGET_USB_FUNCS"
set_prop persist.service.adb.enable 1

for _ in 1 2 3 4 5 6; do
  sleep 5
  CURRENT="$(getprop sys.usb.config)"
  if echo "$CURRENT" | grep -q "diag"; then
    log_msg "sys.usb.config is now $CURRENT"
    break
  fi
  log_msg "Reapplying USB functions, current sys.usb.config=$CURRENT"
  if [ -n "$SVC_BIN" ]; then
    "$SVC_BIN" usb setFunctions "$TARGET_USB_FUNCS" >/dev/null 2>&1
  fi
  set_prop sys.usb.config "$TARGET_USB_FUNCS"
done

if [ -n "$(getprop sys.usb.config)" ]; then
  log_msg "Current sys.usb.config=$(getprop sys.usb.config)"
fi
