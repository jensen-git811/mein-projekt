# Vili Snoopsnitch DIAG

Magisk module for rooted Xiaomi 11T Pro (`vili`) devices to keep Qualcomm USB DIAG available for Snoopsnitch/QCSuper.

## What it does

- sets `persist.sys.usb.config=diag,adb`
- also tries `persist.vendor.usb.config=diag,adb` and `persist.usb.config=diag,adb`
- re-applies `sys.usb.config=diag,adb` after boot and retries for a short window
- keeps ADB enabled via `persist.service.adb.enable=1`

## What it does not do

- it does not add a missing kernel DIAG driver
- it does not guarantee SnoopSnitch will initialize on every boot

## Install

1. Zip the module directory.
2. Install the zip from the Magisk app.
3. Reboot.
4. Check whether the USB mode exposes DIAG to Snoopsnitch or QCSuper.
5. If needed, inspect `/data/adb/cellsentinel-diag.log`.

## Disable

Create this file on the device and reboot:

`/data/adb/cellsentinel-diag.disable`

Delete the file and reboot to re-enable the module.

## Troubleshooting

- If USB functions break, delete the disable file or remove the module from Magisk.
- If SnoopSnitch still reports no DIAG interface, the kernel/userspace USB policy is still blocking DIAG.
- For the device-specific kernel fix, apply `vili-snoopsnitch-diag.patch` to the kernel tree and rebuild.
